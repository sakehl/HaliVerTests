#include "Halide.h"
#include <stdio.h>

using namespace Halide;

int main(int argc, char *argv[]) {
    bool add_runtime = false;
    bool aot = false;
    std::string s_runntime ("--runtime");
    std::string s_aot ("--aot");

    if(argc > 1)
        for(int i=1; i<argc; i++){
            if(s_runntime.compare(argv[i]) == 0){
                add_runtime = true;
                aot = false;
            }
            if(s_aot.compare(argv[i]) == 0){
                add_runtime = false;
                aot = true;
            }
        }

    Func in("in"), even("even");
    Var x("x");

    // in.require(x >= 0);
    in(x) = 2*x*x;
    // in.context_perm(in(x), frac(1,1));
    // in.ensure(in(x) % 2 == 0);
    
    //forall*, exists
    // input_requirement = forall x . x>=0 && x < 100 : input(x) > 0;
    // output_requirement = forall x . x>=0 && x < 100 : out(x) % 2 == 0 && out(x) > 0;

    // even.require(in(x) % 2 == 0);
    even(x) = in(x) + in(x+1);
    // even.context_perm(in(x), frac(1,2));
    // even.context_perm(in(x+1), frac(1,2));
    // even.context_perm(even(x),frac(1,1));
    // even.ensure(even(x) % 2 == 0);

    Var bx("bx"), tx("tx");
    in.compute_root();
    in.gpu_tile(x, bx, tx, 32, TailStrategy::GuardWithIf);
    even.gpu_tile(x, bx, tx, 32, TailStrategy::GuardWithIf);
    even.bound(x,0,128);

    Target target = get_host_target();
    Target new_target = target
      .with_feature(Target::OpenCL)
      .with_feature(Target::NoAsserts)
      ;
    assert(host_supports_target_device(new_target));
    if(add_runtime){
        compile_standalone_runtime("opencl_runtime.o",new_target);
        even.compile_to_header("even_c.h", {}, "even", new_target);
    }

    if(!add_runtime && !aot)
        even.compile_to_c("even_c.cpp", {}, "even", new_target);

    if(aot)
        even.compile_to_static_library("even_static", {}, "even", new_target);
}